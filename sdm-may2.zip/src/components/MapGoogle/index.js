export { default } from "./MapGoogle";
