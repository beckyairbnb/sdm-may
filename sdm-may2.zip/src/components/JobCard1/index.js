export { default } from "./JobCard1";
