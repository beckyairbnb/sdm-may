export const menuItems = [

  {
    name: "writing-jobs/",
    label: "We're Hiring!",

  },
  {
    name: "content-writing-agency/",
    label: "Why Strategically",
    items : [
      {
        name: "writing-jobs/",
        label: "We're Hiring!",    
      },
      {
        name: "writing-jobs/",
        label: "We're Hiring!",    
      }
    ]
  },

];
