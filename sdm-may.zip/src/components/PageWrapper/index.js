export { default } from "./PageWrapper";
