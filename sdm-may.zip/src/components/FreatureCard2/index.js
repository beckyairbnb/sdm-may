export { default } from "./FreatureCard2";
