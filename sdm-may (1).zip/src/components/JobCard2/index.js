export { default } from "./JobCard2";
