const { hot } = require("react-hot-loader/root")

// prefer default export if available
const preferDefault = m => (m && m.default) || m


exports.components = {
  "component---cache-dev-404-page-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\.cache\\dev-404-page.js"))),
  "component---src-pages-404-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\404.js"))),
  "component---src-pages-blognew-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\blognew.js"))),
  "component---src-pages-calculator-content-marketing-roi-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\calculator\\content-marketing-roi.js"))),
  "component---src-pages-case-study-index-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\case-study\\index.js"))),
  "component---src-pages-case-study-original-kettlebell-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\case-study\\original-kettlebell.js"))),
  "component---src-pages-case-study-sanctions-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\case-study\\sanctions.js"))),
  "component---src-pages-contact-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\contact.js"))),
  "component---src-pages-content-writing-agency-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\content-writing-agency.js"))),
  "component---src-pages-example-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\example.js"))),
  "component---src-pages-faq-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\faq.js"))),
  "component---src-pages-get-a-quote-1-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\get-a-quote\\1.js"))),
  "component---src-pages-get-a-quote-2-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\get-a-quote\\2.js"))),
  "component---src-pages-get-a-quote-3-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\get-a-quote\\3.js"))),
  "component---src-pages-get-a-quote-index-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\get-a-quote\\index.js"))),
  "component---src-pages-guest-post-service-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\guest-post-service.js"))),
  "component---src-pages-index-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\index.js"))),
  "component---src-pages-legal-content-writing-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\legal-content-writing.js"))),
  "component---src-pages-lp-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\lp.js"))),
  "component---src-pages-money-back-guarantee-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\money-back-guarantee.js"))),
  "component---src-pages-pricing-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\pricing.js"))),
  "component---src-pages-retail-content-writing-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\retail-content-writing.js"))),
  "component---src-pages-samples-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\samples.js"))),
  "component---src-pages-seo-strategy-agency-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\seo-strategy-agency.js"))),
  "component---src-pages-success-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\success.js"))),
  "component---src-pages-website-copywriting-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\pages\\website-copywriting.js"))),
  "component---src-templates-blog-list-template-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\templates\\BlogListTemplate.js"))),
  "component---src-templates-blog-template-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\templates\\blog-template.js"))),
  "component---src-templates-career-template-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\templates\\career-template.js"))),
  "component---src-templates-category-template-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\templates\\CategoryTemplate.js"))),
  "component---src-templates-job-template-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\templates\\job-template.js"))),
  "component---src-templates-main-service-template-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\templates\\main-service-template.js"))),
  "component---src-templates-page-template-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\templates\\page-template.js"))),
  "component---src-templates-service-template-js": hot(preferDefault(require("F:\\Gatsby-projects\\sdm-may2\\src\\templates\\service-template.js")))
}

